package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.Outils.client_par_souscription;
import com.sodyam.philomabtontine.R;

public class Client_par_souscription extends AppCompatActivity {
    private Button quiter_client_par_souscription;
    private SearchView zone_recherche_souscription;
    private int souscription_recherche;
    private TextView nombre_total_souscription,montant_dernier_paiement,date_dernier_paiement,nom_cli,prenom_cli,
        telephone_cli,montant_paye,reste_paye,valeur_souscript,date_actuelle;
    private Databasephilomabtontine database;
    private RecyclerView recyclerView;
    private  ClientParSouscriptionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_par_souscription);
        this.zone_recherche_souscription=findViewById(R.id.zone_recherche_souscription);
        souscription_recherche=zone_recherche_souscription.getInputType();
        this.nombre_total_souscription=findViewById(R.id.nombre_total_souscription);

        /**
         * INITIALISONS LA BASE DE DONNEES
         */
     database=Databasephilomabtontine.getInstance(getApplicationContext());

        /**
         * AFFICHAGE DES INFORMATIONS DE LA BASE DE DONNEES
         */
        for(client_par_souscription client : database.PaiementDao().getClientBySouscription())
        {
            recyclerView = findViewById(R.id.Unclient_souscription);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new ClientParSouscriptionAdapter(getApplicationContext(), database.PaiementDao().getClientBySouscription());
            recyclerView.setAdapter(adapter);
        }

        this.quiter_client_par_souscription=findViewById(R.id.btn_quitter_client_par_souscription);
       quiter_client_par_souscription.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent VersAjout_nouveau_Agent = new Intent(getApplicationContext(), com.sodyam.philomabtontine.Vue.Menu.class);
               startActivity(VersAjout_nouveau_Agent);
               finish();
           }
       });
    }
}
