package com.sodyam.philomabtontine.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName ="T_Client", indices = {@Index(value = {"Matricule"}, unique = true)})
public class T_Client{
        /**
         * @param args the command line arguments
         */

        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name ="Matricule")
        @NonNull
        private int Matricule;

    @ColumnInfo(name ="Nom")
        private String Nom;

    @ColumnInfo(name ="Prenom")
        private String Prenom;

    @ColumnInfo(name ="DateNaissance")
        private Integer DateNaissance;

    @ColumnInfo(name ="LieuNaissance")
        private String LieuNaissance;

    @ColumnInfo(name ="Sexe")
        private String Sexe;

    @ColumnInfo(name ="Adresse")
        private String Adresse;

    @ColumnInfo(name ="Telephone")
        private String Telephone;

    @ColumnInfo(name ="DateSouscription")
        private Integer DateSouscription;

    @ColumnInfo(name ="Profession")
        private  String Profession;

    @ColumnInfo(name ="agent_enregistreur")
    private  String agent_enregistreur;


    public T_Client() {

    }


    public T_Client(String nom, String prenom, Integer dateNaissance, String lieuNaissance, String sexe, String adresse, String telephone, Integer dateSouscription, String profession, String agent_enregistreur) {
        Nom = nom;
        Prenom = prenom;
        DateNaissance = dateNaissance;
        LieuNaissance = lieuNaissance;
        Sexe = sexe;
        Adresse = adresse;
        Telephone = telephone;
        DateSouscription = dateSouscription;
        Profession = profession;
        this.agent_enregistreur = agent_enregistreur;
    }

    public int getMatricule() {
        return Matricule;
    }

    public void setMatricule(int matricule) {
        Matricule = matricule;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String nom) {
        Nom = nom;
    }

    public String getPrenom() {
        return Prenom;
    }

    public void setPrenom(String prenom) {
        Prenom = prenom;
    }



    public String getLieuNaissance() {
        return LieuNaissance;
    }

    public void setLieuNaissance(String lieuNaissance) {
        LieuNaissance = lieuNaissance;
    }

    public String getSexe() {
        return Sexe;
    }

    public void setSexe(String sexe) {
        Sexe = sexe;
    }

    public String getAdresse() {
        return Adresse;
    }

    public void setAdresse(String adresse) {
        Adresse = adresse;
    }

    public String getTelephone() {
        return Telephone;
    }

    public void setTelephone(String telephone) {
        Telephone = telephone;
    }



    public String getProfession() {
        return Profession;
    }

    public void setProfession(String profession) {
        Profession = profession;
    }

    public Integer getDateNaissance() {
        return DateNaissance;
    }

    public void setDateNaissance(Integer dateNaissance) {
        DateNaissance = dateNaissance;
    }

    public Integer getDateSouscription() {
        return DateSouscription;
    }

    public void setDateSouscription(Integer dateSouscription) {
        DateSouscription = dateSouscription;
    }

    public String getAgent_enregistreur() {
        return agent_enregistreur;
    }

    public void setAgent_enregistreur(String agent_enregistreur) {
        this.agent_enregistreur = agent_enregistreur;
    }

    @Override
    public String toString() {
        return "T_Client{" +
                "Matricule=" + Matricule +
                ", Nom='" + Nom + '\'' +
                ", Prenom='" + Prenom + '\'' +
                ", DateNaissance=" + DateNaissance +
                ", LieuNaissance='" + LieuNaissance + '\'' +
                ", Sexe='" + Sexe + '\'' +
                ", Adresse='" + Adresse + '\'' +
                ", Telephone='" + Telephone + '\'' +
                ", DateSouscription=" + DateSouscription +
                ", Profession='" + Profession + '\'' +
                '}';
    }
}


