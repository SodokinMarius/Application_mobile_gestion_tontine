package com.sodyam.philomabtontine.Vue;

import static com.sodyam.philomabtontine.Outils.DateConverter.ConvertDateToString;
import static com.sodyam.philomabtontine.Outils.DateConverter.convertDateStringToInteger;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.sodyam.philomabtontine.ContentViewModel;
import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.Injection.Injection;
import com.sodyam.philomabtontine.Injection.viewModelFactory;
import com.sodyam.philomabtontine.R;
import com.sodyam.philomabtontine.model.T_Carnet;
import com.sodyam.philomabtontine.model.T_Client;
import com.sodyam.philomabtontine.model.T_Client_Lot;
import com.sodyam.philomabtontine.model.T_Lot;
import com.sodyam.philomabtontine.utils.Functions;

import java.util.Date;

public class nouveau_client extends AppCompatActivity {
    private Button bouton_enregister_nouveau_client,btn_quiter_nouveau_client;
    private TextView date_actuelle;
    private EditText numcarnet,nom_client,prenom_client,date_naissance,lieu_naissance,adresse_client,
                        profession_client,telephone,agent_enregistreur;

    private EditText montant_souscrit;

    private Date date_souscription=new Date();
    private T_Client nouveau_client;
    private nouveau_client Nouveau_client;
    private T_Lot nouveau_Lot;
    private T_Client_Lot nouveau_Client_lot;
    private T_Carnet  nouveau_carnet;
    private ContentViewModel mContentViewModel;
    private Databasephilomabtontine database;
    private Spinner poste_enregistreur,sexe_client, type_lot;

    /**
     *  Declaration des variables
     */
    Integer numero_carnet;
    String nomClient,prenomClient,lieuNaissance,sexeClient,adresseClient,professionClient,tel,type_lot_convertir;
    String dateNaissance,dateEnregistrement,dateActuelle;



    Integer montant_souscription;

    /**
     *  CONVERTION DE LA DATE ACTUELLE
     */
    String date_=ConvertDateToString(new java.sql.Date(0));
    Integer date_debut=convertDateStringToInteger(date_);


    Date date_du_lot_existant=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nouveau_client);
        configureContentViewModel();


        /**
         * IMPLEMENTATION DU SPINNER
         */
        poste_enregistreur = (Spinner) findViewById(R.id.agent_enregistreur);
        this.sexe_client=(Spinner) findViewById(R.id.sexe_client);
        this.type_lot=(Spinner) findViewById(R.id.type_lot);


        /**
         * FOR POSTE
         */
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterForPoste = ArrayAdapter.createFromResource(this,
                R.array.postes, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterForPoste.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        poste_enregistreur.setAdapter(adapterForPoste);
       // poste_enregistreur.getSelectedItem().toString();
//        poste_occupe=spinner;


        /**
         * FOR SEXE
         */
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterForSexe = ArrayAdapter.createFromResource(this,
                R.array.sexe, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterForSexe.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        sexe_client.setAdapter(adapterForSexe);

        /**
         * FOR TYPE LOT
         */

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterForTypeLot = ArrayAdapter.createFromResource(this,
                R.array.typeLot, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterForTypeLot.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        type_lot.setAdapter(adapterForTypeLot);



        this.bouton_enregister_nouveau_client=(Button)findViewById(R.id.btn_enregistre_client);
        this.btn_quiter_nouveau_client=findViewById(R.id.btn_quiter_nouveau_client);


        btn_quiter_nouveau_client.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersMenu=new Intent(getApplicationContext(),Menu.class);
                startActivity(VersMenu);
                finish();
            }
        });

        //Action après clic sur le boutton enregistrer
        bouton_enregister_nouveau_client.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                init();
                ConvertToString();
                montant_souscription=Integer.parseInt(montant_souscrit.getText().toString());

                if(EstNonVide() && EntreesEstCorrect() ) {

                    AlertDialog.Builder maboite_confirmation = new AlertDialog.Builder(Nouveau_client);
                    maboite_confirmation.setTitle("Confirmation de l'Ajout");
                    maboite_confirmation.setMessage("Vous voulez ajouter le client " + nomClient + " " + prenomClient +
                            " né (e) le " + date_naissance + " à " + lieuNaissance + " avec les informations ci après : \n" + " Adresse :" +
                            adresseClient + " Contact : " + tel + " ; Profession : " +professionClient + " \n" +
                            " Voulez vous continuer ? ");

                    maboite_confirmation.setPositiveButton("CONTINUER", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            insertNewClient();
                            createNewcCarnet();

                            if (!CeLotExiste(montant_souscription)) {
                                createNewLot();

                            }
                            CreateNewClientLot();


                            //Affichage d'un texte d'assurance
                            Toast.makeText(getApplicationContext(), "Informations  Bien enregistrées", Toast.LENGTH_SHORT).show();

                        }
                    });
                    maboite_confirmation.setNegativeButton("ANNULER", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getApplicationContext(), "Enregistrement Annulé", Toast.LENGTH_SHORT).show();
                        }
                    });
                    maboite_confirmation.show();
                }
            }
        });
    }

    /**
     * CONFIGURATON DU CONTENT VIEWMODEL
     */
    private void configureContentViewModel()
    {
        viewModelFactory mviewModelFactory=
                Injection.getViewModelFactory(this);
        this.mContentViewModel= ViewModelProviders.of(this, (ViewModelProvider.Factory) mviewModelFactory)
                .get(ContentViewModel.class);
    }

    /**
     * Initialisation et recuperation des variables
      */
    private void init()
    {
        this.date_actuelle=(TextView) findViewById(R.id.date_actuelle);
        this.numcarnet= (EditText) findViewById(R.id.numCarnet);
        this.nom_client=(EditText) findViewById(R.id.nom_client);
        this.prenom_client=(EditText) findViewById(R.id.prenom_client);
        this.date_naissance=(EditText) findViewById(R.id.date_naiss);
        this.lieu_naissance=(EditText) findViewById(R.id.lieu_naissance);
        this.adresse_client=(EditText) findViewById(R.id.adresse_client);
        this.telephone=(EditText) findViewById(R.id.saisi_num_phone);
        this.profession_client=(EditText) findViewById(R.id.profession_client);
        this.montant_souscrit=(EditText) findViewById(R.id.souscription);

        this.Nouveau_client=this;
    }

    /**
     * Initialisons les variables à envoyer pour la création du client;
     * @param
     */
    public void ConvertToString()  {
        init();
       Integer num_carnet=Integer.parseInt(numcarnet.getText().toString());
       nomClient=nom_client.getText().toString();
      prenomClient= prenom_client.getText().toString();
       // SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
       // dateNaissance =date_naissance.toString();
       lieuNaissance=lieu_naissance.getText().toString();
       //sexeClient=sexe_client.getText().toString();
       adresseClient=adresse_client.getText().toString();
       tel=telephone.getText().toString();
       professionClient=profession_client.getText().toString();
     // poste_enregistreur.toString();

    }

    /**
     * INSERER UN NOUVEAU CLIENT
     */
    private void insertNewClient() {
         init();
        T_Client client=new T_Client(nomClient,prenomClient,convertDateStringToInteger(date_naissance.getText().toString()),lieuNaissance,
                sexe_client.getSelectedItem().toString(),adresseClient,tel,date_debut,
                professionClient,poste_enregistreur.getSelectedItem().toString());
        this.mContentViewModel.insertClient(client);
    }

    /**
     * CREER UN NOUVEAU CARNET
     */
    private void createNewcCarnet()
    {
        Databasephilomabtontine database=Databasephilomabtontine.getInstance(getApplicationContext());
        int num_card=0;
        if(database.CarnetDao().getListeCarnets().size()==0)
        {
            T_Carnet nouveau_carnet=new T_Carnet(1,
                    montant_souscription,date_debut);
            database.CarnetDao().createCarnet(nouveau_carnet);
        }
        else
        {
            T_Carnet nouveau_carnet=new T_Carnet(database.ClientDao().getDernierClientEnregistre()+1,
                    montant_souscription,date_debut);
            database.CarnetDao().createCarnet(nouveau_carnet);
        }

    }

    /**
     *CREER UN LOT
     */
    private void  createNewLot()
    {
        Databasephilomabtontine database=Databasephilomabtontine.getInstance(getApplicationContext());
        T_Lot nouveau_lot=new T_Lot(montant_souscription,type_lot.getSelectedItem().toString(),date_debut,
              date_debut);
        database.LotDao().insertLot(nouveau_lot);
    }

    /**
     * CREER UN CLIENT_LOT
     */
    private  void  CreateNewClientLot()
    {
        Databasephilomabtontine database=Databasephilomabtontine.getInstance(getApplicationContext());
        T_Client_Lot nouveau_Client_Lot=new T_Client_Lot(database.ClientDao().getDernierClientEnregistre()+1,
                database.Client_LotDao().getDernierClientLotEnregistre()+1);
          database.Client_LotDao().insertCient_lot(nouveau_Client_Lot);
    }


    public Boolean EntreesEstCorrect()
    {

        Boolean correct=true;
        try {
            //Conversion du numero de Carnet et du montant lot  entré en type Entier
            numero_carnet=0;

            numero_carnet=Integer.parseInt(numcarnet.getText().toString());



            //Controle de l'existence ou non du numero de carnet
            Integer nombre_carnet=mContentViewModel.getNombreTotalCarnetVendu();

                if(mContentViewModel.getListesNumerosCarnets().contains(numero_carnet))
                {
                    correct=false;
                    Toast.makeText(nouveau_client.this, "Ce Carnet existe déjà ! ", Toast.LENGTH_SHORT).show();

                }
                if(montant_souscription%25!=0 || montant_souscription<25)
                {
                    correct=false;
                    Toast.makeText(nouveau_client.this, "Montant Invalide ! ", Toast.LENGTH_SHORT).show();
                }

            if(numero_carnet<=0)
            {
                correct=false;
                Toast.makeText(nouveau_client.this, "Veuillez saisir un numero correct", Toast.LENGTH_SHORT).show();
            }

        }catch(Exception err){    }
        return  correct;

    }

    //Fonction qui verifie si les champs sont entrées
    public Boolean EstNonVide() {
        Boolean NonVide = true;
        try {
            if (
                    Functions.checkIsEmpty(this,numcarnet) &&
                    Functions.checkIsEmpty(this,nom_client) &&
                    Functions.checkIsEmpty(this,prenom_client) &&
                    Functions.checkIsEmpty(this,date_naissance) &&
                    Functions.checkIsEmpty(this,lieu_naissance) &&
                    Functions.checkIsEmpty(this,adresse_client) &&
                    Functions.checkIsEmpty(this,telephone) &&
                    Functions.checkIsEmpty(this,agent_enregistreur) &&
                    Functions.checkIsEmpty(this,profession_client) &&
                    Functions.checkIsEmpty(this,montant_souscrit)
            )
            {
                Toast.makeText(nouveau_client.this, "Un des champs n'est pas renseigné !", Toast.LENGTH_SHORT).show();
                NonVide = false;
            }
        } catch (Exception error) {

        }

        return NonVide;

    }
    /**
     * Avant de faire l'insertion du lot dans la BD, verifions si ce dernier n'existe pas encore.
     * Cas échéant, envoyons lui la date de son premier enregistrement
     */
//
    public Boolean CeLotExiste(Integer montant_verifier)
    {
        Boolean lot_Existe=false;

        try {
            if(mContentViewModel.getListesMontantLotsExistant().contains(montant_verifier))
            {
                lot_Existe=true;
            }

        }catch (Exception error){    }
        return lot_Existe;
    }

}