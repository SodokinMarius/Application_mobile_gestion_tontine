package com.sodyam.philomabtontine.utils;

import android.app.Activity;
import android.widget.EditText;

import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.R;
import com.sodyam.philomabtontine.model.T_Agent;

public class Functions {
    public static void initDatabase(Activity activity) {
        Databasephilomabtontine database = Databasephilomabtontine.getInstance(activity);
        if (database.AgentDao().getListeAgents().size() == 0) {
            T_Agent t_agent = new T_Agent();
            t_agent.setAdresse("GODOMEY");
            t_agent.setNomAgent("Tata");
            t_agent.setPrenomAgent("Soeur Femi");
            t_agent.setDateDeDebut(11112021);
            t_agent.setPoste("SUPERVISEUR");
            t_agent.setDateDeNaissance(10201981);
            t_agent.setLieuDeNaissance("TOVIKLIN");
            t_agent.setTelephone("66562771");
            t_agent.setMot_de_passe("SUP6656");
            database.AgentDao().insertAgent(t_agent);
        }
    }

    public static boolean checkIsEmpty(Activity activity, EditText editText) {
        String input = editText.getText().toString().trim();
        if (input.isEmpty()) {
            editText.setError(activity.getString(R.string.isRequired));
            return false;
        } else {
            editText.setError(null);
            return true;
        }
    }
}
