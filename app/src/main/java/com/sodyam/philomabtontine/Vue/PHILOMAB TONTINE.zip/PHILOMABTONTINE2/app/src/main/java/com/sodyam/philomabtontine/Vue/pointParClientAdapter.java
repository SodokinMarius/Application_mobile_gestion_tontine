package com.sodyam.philomabtontine.Vue;

public class pointParClientAdapter {
}
