package com.sodyam.philomabtontine.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "T_Lot"/* indices = {@Index(value = {"montant_lot"}, unique = true)}*/)
public class T_Lot {


    @PrimaryKey
    @ColumnInfo(name ="montant_lot")
    @NonNull
    private int montant_lot;

    @ColumnInfo(name ="type_lot")
    private String type_lot;

    @ColumnInfo(name ="date_ajout")
    private Integer date_ajout;

    @ColumnInfo(name ="dernier_modification")
    private  Integer dernier_modification;


    public T_Lot() {
    }

    public T_Lot(int montant_lot, String type_lot, Integer date_ajout, Integer dernier_modification) {
        this.montant_lot = montant_lot;
        this.type_lot = type_lot;
        this.date_ajout = date_ajout;
        this.dernier_modification = dernier_modification;
    }

    public int getMontant_lot() {
        return montant_lot;
    }

    public void setMontant_lot(int montant_lot) {
        this.montant_lot = montant_lot;
    }

    public String getType_lot() {
        return type_lot;
    }

    public void setType_lot(String type_lot) {
        this.type_lot = type_lot;
    }

    public Integer getDate_ajout() {
        return date_ajout;
    }

    public void setDate_ajout(Integer date_ajout) {
        this.date_ajout = date_ajout;
    }

    public Integer getDernier_modification() {
        return dernier_modification;
    }

    public void setDernier_modification(Integer dernier_modification) {
        this.dernier_modification = dernier_modification;
    }

    @Override
    public String toString() {
        return "T_Lot{" +
                "montant_lot=" + montant_lot +
                ", type_lot='" + type_lot + '\'' +
                ", date_ajout=" + date_ajout +
                ", dernier_modification=" + dernier_modification +
                '}';
    }
}


