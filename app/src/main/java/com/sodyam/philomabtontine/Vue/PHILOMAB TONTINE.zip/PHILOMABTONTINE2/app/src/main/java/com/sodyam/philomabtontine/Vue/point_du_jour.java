package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.sodyam.philomabtontine.ContentViewModel;
import com.sodyam.philomabtontine.Injection.Injection;
import com.sodyam.philomabtontine.Injection.viewModelFactory;
import com.sodyam.philomabtontine.R;

public class point_du_jour extends AppCompatActivity {
    private TextView date_actuelle;
    private TextView nombre_carnet_vendu,montant_carnet_jour,montant_total_collecte,chiffre_affaire_jour;
    private Button bouton_quiter_point_jour;
    private ContentViewModel mContentViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_du_jour);
        init_poin_jour();
            configureContentViewModel();

        /**
         * AFFICHAGE DES INFORMATIONS RECUPREES DE LA BD
         */
       /* Integer montant_carnet = (Integer) mContentViewModel.getNombreCarnetVenduDernierJour().intValue()* 300;
        nombre_carnet_vendu.setText(mContentViewModel.getNombreCarnetVenduDernierJour().toString());
        montant_carnet_jour.setText(montant_carnet+" F CFA");
        montant_total_collecte.setText(mContentViewModel.getMontantCollecteDernierJour().toString()+" F CFA");
        Integer CAff=(Integer) (montant_carnet+mContentViewModel.getMontantCollecteDernierJour().intValue());
        chiffre_affaire_jour.setText(CAff+" F CFA");*/
        //Redirection vers LE MENU principal après clic sur quitter
        bouton_quiter_point_jour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersMenuPrincipal=new Intent(getApplicationContext(),Menu.class);
                startActivity(VersMenuPrincipal);
                finish();
            }
        });
    }
    private void configureContentViewModel()
    {
        viewModelFactory mviewModelFactory= Injection.getViewModelFactory(this);
        this.mContentViewModel= ViewModelProviders.of(this, (ViewModelProvider.Factory) mviewModelFactory)
                .get(ContentViewModel.class);
    }
    //Recuperation et valorisation des variables
    private void init_poin_jour()
    {
        this.bouton_quiter_point_jour=(Button) findViewById(R.id.btn_quitter_point_jour);
        this.date_actuelle=(TextView) findViewById(R.id.date_actuelle);
        this.nombre_carnet_vendu=(TextView)findViewById(R.id.nombre_carnet_vendu);
        this.montant_carnet_jour=(TextView)findViewById(R.id.montant_carnet);
        this.montant_total_collecte=(TextView)findViewById(R.id.total_quote_part_jour);
        this.chiffre_affaire_jour=(TextView) findViewById(R.id.chiffre_jour);
    }
}

