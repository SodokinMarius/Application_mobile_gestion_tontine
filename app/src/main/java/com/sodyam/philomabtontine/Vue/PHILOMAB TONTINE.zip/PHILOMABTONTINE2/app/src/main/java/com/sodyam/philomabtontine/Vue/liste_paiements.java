package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.sodyam.philomabtontine.R;

public class liste_paiements extends AppCompatActivity {


    private Button bouton_ajout_nouveau_paiement,quiter_liste_paiement;
    private TextView date_actuelle;
    private  TextView montant_total_encaisse,agent_operateur,numcarnet,nom_cli,prenom_cli,reste_a_payer,
     montant_dernier_paye,date_dernier_paye;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_paiements);
        init();
        this.bouton_ajout_nouveau_paiement=(Button) findViewById(R.id.btn_ajout_nouveau_paiement);
        this.quiter_liste_paiement=findViewById(R.id.btn_quiter_liste_paiment);
        //Action de redirection vers le fomulaire de nouveau paiment
        bouton_ajout_nouveau_paiement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersAjout_paiement=new Intent(liste_paiements.this, com.sodyam.philomabtontine.Vue.nouveau_paiement.class);
                startActivity(VersAjout_paiement);
                finish();

            }
        });

        quiter_liste_paiement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersMenu=new Intent(getApplicationContext(),Menu.class);
                startActivity(VersMenu);
                finish();
            }
        });
    }

    private void init()
    {
        this.date_actuelle=(TextView) findViewById(R.id.date_actuelle);
        this.montant_total_encaisse=(TextView) findViewById(R.id.montant_total_encaisse);
        this.agent_operateur=(TextView)findViewById(R.id.agent_enregistreur);
        this.numcarnet=(TextView)findViewById(R.id.numCarnet);
        this.nom_cli=(TextView)findViewById(R.id.nom_client);
        this.prenom_cli=(TextView)findViewById(R.id.prenom_client);
        this.reste_a_payer=(TextView)findViewById(R.id.reste_paye);

    }
}