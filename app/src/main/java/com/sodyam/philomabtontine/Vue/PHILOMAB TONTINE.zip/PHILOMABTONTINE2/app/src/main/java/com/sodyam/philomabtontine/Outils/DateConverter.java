package com.sodyam.philomabtontine.Outils;

import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.room.TypeConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sodyam.philomabtontine.model.T_Agent;
import com.sodyam.philomabtontine.model.T_Client;
import com.sodyam.philomabtontine.model.T_Paiement;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.sql.Date;
import java.util.List;

public class DateConverter {
 private List<client_par_souscription> clientsParSouscription;
 private  List <pointParTypeLot> mPointParTypeLots;
 private List<T_Client> Clients;
 private  List<T_Agent> Agents;
 private List <T_Paiement> Paiements;

    public DateConverter() {
    }

    //dates
    @TypeConverter
    public static String ConvertFromSourceToString(T_Agent agent)
    {
        return agent.toString();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public static Date ConvertStringToDate(String date) {
        String FormatNormal = "YYYY-MM-dd";
        //EEE MMM dd hh:mm:ss 'GMT' yyyy
        SimpleDateFormat Formater = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Formater = new SimpleDateFormat(FormatNormal);
        }
        try {
            Date dateconvert = (Date) Formater.parse(FormatNormal);
            return dateconvert;
        } catch (Exception error) {
        }
        //Log.d("erreur de convertion ", " Date incorrect ! "+error.toString())   }
        return new Date(0);
    }

    @TypeConverter
    public static String ConvertDateToString(Date dateConvert)
    {
        SimpleDateFormat DateFormat = new SimpleDateFormat("yyyy-mm-dd");
        return DateFormat.format(dateConvert);
    }

    /**
     * CONVERTION DES DATES
     * @param value
     * @return
     */
    @TypeConverter
    public Date fromTimestamp(Long value) {
        return value == null ? null : new Date(value);
    }

    @TypeConverter
    public Long dateToTimestamp(Date date) {
        if (date == null) {
            return null;
        } else {
            return date.getTime();
        }
    }

    /**
     * ====== CONVERTION DES OBJETS  LISTE DES CLIENTS==============
     * @param data
     * @return
     */
    @TypeConverter
    public static List<T_Client> storedStringToMyObjects(String data) {
        Gson gson = new Gson();
        if (data == null) {
            return Collections.emptyList();
        }
        Type listType = new TypeToken<List<T_Client>>() {}.getType();
        return gson.fromJson(data, listType);
    }

    @TypeConverter
    public static String myObjectsToStoredString(List<T_Client> myObjects) {
        Gson gson = new Gson();
        return gson.toJson(myObjects);
    }

    /**
     * METODES DE GESTION DES DATES INTEGER ET STRING
     * @param date
     * @return
     */
    public static Integer convertDateStringToInteger(String date)
    {
        //Supression des espaces et du symbolle Slash /
        String dateEnv;
        String symb="/";
        if (date.contains(symb))
        {
            dateEnv=date.trim().replaceAll("/","");
        }

        else {
            dateEnv=date.trim().replaceAll("-","");
        }

        //Convertion de la date en type INTEGER
        return Integer.parseInt(dateEnv);
    }
    public static String convertDateIntegerToString(Integer date)
    {
       return Integer.toString(date);
    }

    public String AjoutSymbollToStringDate(String date)
    {
        return  date.replaceAll("/","-");
    }
    /**
     * SECTIONNER UNE DATE INT EN JOUR MOIS ANNEE
     */

    public String ConvertNumericDateIntoAllLetter(Integer date)
    {
        String dateCaract=convertDateIntegerToString(date);
        Integer jour=Integer.parseInt(dateCaract.substring(0,2));
        Integer mois=Integer.parseInt(dateCaract.substring(3,5));
        Long moisL=Long.valueOf(mois.intValue());
        Integer annee=Integer.parseInt(dateCaract.substring(5));
        String day,month;
        switch (jour)
        {
            case 01:
                day="Lundi";
                break;
            case 02:
                day="Mardi";

            case 03:
                day="Mercredi";
            case 04:
                day="Jeudi";
            case 05:
                day="Vendredi";
            case 06:
                day="Samedi";
            case 07:
                day="Dimanche";
            default:
                day="Error";

        }

  switch (mois){
      case 01:
          month = "Janvier";
      case 02:
          month = "Fevrier";
      case 03:
          month = "Mars";
      case 04:
          month="Avril";
      case 05:
          month="Mai";
      case 06:
          month="Juin";
      case 07:
          month="Juillet";
      case 8:
          month="Août";
      case 9:
          month="Septembre";
      case 10:
          month="Octobre";
      case 11:
          month="Novembre";
      case 12:
          month="Décembre";
      default:
          month="Error";

  }
   return  day+" "+month+" "+annee;

    }


}
