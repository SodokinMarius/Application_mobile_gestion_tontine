package com.sodyam.philomabtontine.Vue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sodyam.philomabtontine.Outils.Point_par_souscription;
import com.sodyam.philomabtontine.R;

import java.util.List;

public class PointParSouscriptionAdapter extends RecyclerView.Adapter<PointParSouscriptionAdapter.ExampleViewHolder> {
    private Context mContext;
    private List<Point_par_souscription> mExampleList;
    private PointParSouscriptionAdapter.OnItemClickListenner mListenner;

    public interface OnItemClickListenner {
        void onItemClick(int position);
    }

    public void setOnClickListenner(PointParSouscriptionAdapter.OnItemClickListenner listenner) {
        mListenner = listenner;
    }
    public PointParSouscriptionAdapter(Context context, List<Point_par_souscription> example_categoryList) {
        mContext = context;
        mExampleList = example_categoryList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PointParSouscriptionAdapter.ExampleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.point_par_souscription_single_item, parent, false);
        return new PointParSouscriptionAdapter.ExampleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PointParSouscriptionAdapter.ExampleViewHolder holder, int position) {
       Point_par_souscription currentItem = mExampleList.get(position);
       holder.souscription_valeur.setText(currentItem.getSouscription().intValue()+" F CFA ");
       holder.nbre_client.setText(currentItem.getNombre_client());
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }

    public class ExampleViewHolder extends RecyclerView.ViewHolder{

        private TextView nbre_client;
        private TextView souscription_valeur;

        public ExampleViewHolder(View itemView) {
            super(itemView);
           nbre_client=itemView.findViewById(R.id.nbre_client);
           souscription_valeur=itemView.findViewById(R.id.souscription_valeur);
        }
    }
}
