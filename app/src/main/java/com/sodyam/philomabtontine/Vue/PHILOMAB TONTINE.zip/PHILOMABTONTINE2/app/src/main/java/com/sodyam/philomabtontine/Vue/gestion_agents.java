package com.sodyam.philomabtontine.Vue;

import static com.sodyam.philomabtontine.Outils.DateConverter.ConvertDateToString;
import static com.sodyam.philomabtontine.Outils.DateConverter.convertDateStringToInteger;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import com.sodyam.philomabtontine.ContentViewModel;
import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.Injection.Injection;
import com.sodyam.philomabtontine.Injection.viewModelFactory;
import com.sodyam.philomabtontine.R;
import com.sodyam.philomabtontine.model.T_Agent;
import com.sodyam.philomabtontine.utils.Functions;

import java.sql.Date;

public class gestion_agents extends AppCompatActivity {

    private ContentViewModel mContentViewModel;
    private EditText nom_agent,prenom_agent,date_naissance,lieu_naissance,telephone,adreese_agent,poste_agent,
            mot_passe,mot_passe_confirm;

    private String nomagent,prenomagent,lieunaissance,telephon,adreeseagent,posteagent,
            motpasse,motpasse_confirm;
   String datenaissance;

    private Button enregistrer_nouveau_agent, btn_quiter_nouveau_agent;
    private gestion_agents NouveauAgent;
    private T_Agent nouveau_agent;
    Databasephilomabtontine database;


    /**
     * CONVERTION DE LA DATE ACTUELLE
     * @param
     */

    String date_=ConvertDateToString(new Date(0));
    Integer date_debut=convertDateStringToInteger(ConvertDateToString(new Date(0)));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_agents);
        init();
        //configureViewModel();
        enregistrer_nouveau_agent=(Button) findViewById(R.id.btn_enregistre_agent);
        btn_quiter_nouveau_agent=(Button) findViewById(R.id.btn_quiter_nouveau_agent);

        /**
         * NULL
         */
        enregistrer_nouveau_agent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(ChampAgentEstVide()){
                    if(MotDePasseEstConforme()){
                        //configureViewModel();

                        Log.e("TAG","ici");

                        ConvertToString();
                        database=Databasephilomabtontine.getInstance(getApplicationContext());

                        T_Agent newAgent= new T_Agent(posteagent, nomagent, prenomagent, convertDateStringToInteger(datenaissance),lieunaissance,telephon,adreeseagent,motpasse,date_debut);
                        database.AgentDao().insertAgent(newAgent);
                        Toast.makeText(getApplicationContext(), getString(R.string.confirmAgentInsertion), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Non correct", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Vide", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /**
         * ============== ACTION APRES CLIC SUR LE BOUTON QUITTER
         */
        btn_quiter_nouveau_agent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersMenu=new Intent(getApplicationContext(),Menu.class);
                startActivity(VersMenu);
                finish();

            }
        });
    }

    // 2 - Configuring ViewModel
    private void configureViewModel(){
        viewModelFactory mViewModelFactory = Injection.getViewModelFactory(this);
        this.mContentViewModel = ViewModelProviders.of(this, mViewModelFactory).get(ContentViewModel.class);
    }

    private void init(){
        this.nom_agent=(EditText) findViewById(R.id.nom_agent);
        this.prenom_agent=(EditText)findViewById(R.id.prenom_agent);
        this.date_naissance=(EditText)findViewById(R.id.date_naissance);
        this.lieu_naissance=(EditText)findViewById(R.id.lieu_naissance);
        this.telephone=(EditText)findViewById(R.id.telepnone_agent);
        this.adreese_agent=(EditText)findViewById(R.id.adresse_agent);
        this.poste_agent=(EditText)findViewById(R.id.poste_agent);
        this.mot_passe=(EditText)findViewById(R.id.passwd_agent);
        this.mot_passe_confirm=(EditText)findViewById(R.id.confirm_passwd);
    }


    /**
     * Convertion des variables captées en type String
     */
    public void ConvertToString(){
        init();
        nomagent=nom_agent.getText().toString();
        prenomagent=prenom_agent.getText().toString();
        datenaissance=date_naissance.getText().toString();
        lieunaissance=lieu_naissance.getText().toString();
        telephon=telephone.getText().toString();
        adreeseagent=adreese_agent.getText().toString();
        posteagent=poste_agent.getText().toString();
        motpasse=mot_passe.getText().toString();
        motpasse_confirm=mot_passe_confirm.getText().toString();
    }

    /**
     * Faire une écoute sur le bouton enregistrer un nouveau client
     */


    /**
     * Verifions si tous les champs sont renseignés
     */
    private boolean ChampAgentEstVide()
    {

        return (Functions.checkIsEmpty(this,nom_agent) &&
                Functions.checkIsEmpty(this,prenom_agent) &&
                Functions.checkIsEmpty(this,date_naissance)&&
                Functions.checkIsEmpty(this,lieu_naissance)&&
                Functions.checkIsEmpty(this,telephone)&&
                Functions.checkIsEmpty(this,adreese_agent)&&
                Functions.checkIsEmpty(this,mot_passe) &&
                Functions.checkIsEmpty(this,mot_passe_confirm));
            }

    /**
     * Verification de la conformité des mot de passe
     */
    private boolean MotDePasseEstConforme()
    {
        Boolean mot_de_passe_conforme=false;
        try
        {
            if(mot_passe.getText().toString().trim().equals(mot_passe_confirm.getText().toString().trim()))
            {
                Toast.makeText(gestion_agents.this, "Les mot de passes ne sont pas conformes ! ", Toast.LENGTH_SHORT).show();
                mot_de_passe_conforme=true;
            }
        }catch (Exception error){ }
        return mot_de_passe_conforme;
    }

}
