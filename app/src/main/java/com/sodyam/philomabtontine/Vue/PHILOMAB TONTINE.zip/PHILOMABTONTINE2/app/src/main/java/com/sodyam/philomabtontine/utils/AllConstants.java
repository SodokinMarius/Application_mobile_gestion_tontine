package com.sodyam.philomabtontine.utils;

public interface AllConstants {
    String TAG = "TONTINE";
}
