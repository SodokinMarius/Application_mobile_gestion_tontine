package com.sodyam.philomabtontine.Vue;

import static android.content.ContentValues.TAG;
import static com.sodyam.philomabtontine.Outils.DateConverter.ConvertDateToString;
import static com.sodyam.philomabtontine.Outils.DateConverter.convertDateStringToInteger;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.sodyam.philomabtontine.ContentViewModel;
import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.Injection.Injection;
import com.sodyam.philomabtontine.Injection.viewModelFactory;
import com.sodyam.philomabtontine.R;
import com.sodyam.philomabtontine.model.T_Client;
import com.sodyam.philomabtontine.model.T_Paiement;
import com.sodyam.philomabtontine.utils.Functions;

import java.util.Date;


public class nouveau_paiement extends AppCompatActivity {
    private Button bouton_actualiser_paiement,bouton_enregister_paiement,btn_quiter_paiement;
    private TextView date_actuelle;

    private EditText numcarnet,quote_part;
    private  Spinner poste_agentE;
    private  TextView nom_client,prenom_client,telephone,montant_payer,reste_payer;
    private  T_Paiement nouveau_paiement;
    private T_Client Client_Conserne;
    private ContentViewModel mContentViewModel;
    private T_Client mInfosPaiementsDuClient;
     private  Integer date_paiement;
     private  Spinner poste;
     private Databasephilomabtontine database;
         Date Date_actu=new Date();
    Integer num_carnet;
    Integer montant;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nouveau_paiement);
        init();


         this.bouton_actualiser_paiement=(Button) findViewById(R.id.btn_actualiser_paiement);
         this.bouton_enregister_paiement=(Button) findViewById(R.id.btn_enregistre_paiement);
         this.btn_quiter_paiement=(Button) findViewById(R.id.btn_quiter_paiement);


         /**
          * IMPLEMENTATION DU SPINNER
          */
         poste = (Spinner) findViewById(R.id.agent_enregistreur);
         // Create an ArrayAdapter using the string array and a default spinner layout
         ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                 R.array.postes, android.R.layout.simple_spinner_item);
         // Specify the layout to use when the list of choices appears
         adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
         // Apply the adapter to the spinner
         poste.setAdapter(adapter);
//        poste_occupe=spinner;



         /**
          * CONVERTION DE LA DATE ACTUELLE
          * @param
          */

         String date_=ConvertDateToString(new java.sql.Date(0));
         date_paiement=convertDateStringToInteger(date_);

         /**
          * INITIALISATION DE LA BASE DE DONNEES
          */
         database=Databasephilomabtontine.getInstance(getApplicationContext());
         /**

          *
          * ============== ACTION APRES CLIC SUR LE BOUTON ACTUALISER
          */
         bouton_actualiser_paiement.setOnClickListener(new Button.OnClickListener() {
             @SuppressLint("WrongViewCast")
             @Override
             public void onClick(View view) {
                 init();
                 //configureContentViewModel();
                 num_carnet=Integer.parseInt(numcarnet.getText().toString());
                 Log.e(TAG,"NUMERO DU CLIENT RECHERCHE : -------------------------------"+ num_carnet);
                 Log.e(TAG,"LISTE DES PAIEMENTS : -------------------------------"+ database.PaiementDao().getListePaiements().size());
                 if(CartnetExiste(num_carnet))
                 {
                     montant=Integer.parseInt(quote_part.getText().toString());
                     nom_client.setText(database.ClientDao().getClientByNumCarnet(num_carnet).getNom());
                     prenom_client.setText(database.ClientDao().getClientByNumCarnet(num_carnet).getPrenom());
                     telephone.setText(database.ClientDao().getClientByNumCarnet(num_carnet).getTelephone());
                    // montant_payer.setText(database.PaiementDao().getMontantPayeByNumCarnet(num_carnet).intValue());
                     montant_payer.setText(database.PaiementDao().getMontantPayeByNumCarnet(num_carnet).intValue()+" F CFA");
                     reste_payer.setText(database.PaiementDao().getInfosPaiementClientById(num_carnet).getReste_paye()+" F CFA");
                 }
                 else
                 {
                     Toast.makeText(com.sodyam.philomabtontine.Vue.nouveau_paiement.this,"Ce Carnet n'existe pas !!", Toast.LENGTH_SHORT).show();
                 }
             }
         });

         /**
          * ============== ACTION APRES CLIC SUR LE BOUTON QUITTER
          */
         btn_quiter_paiement.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent VersMenu=new Intent(getApplicationContext(),Menu.class);
                 startActivity(VersMenu);
                 finish();

             }
         });

         /**
          * ======== ACTION APRES CLIC SUR LE BOUTON ENREGISTRER ======
          */
         bouton_enregister_paiement.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                  init();
                 // configureContentViewModel();
                  if (ValeursEntreesCorrects() && InfosPaiementEstVide()) {
                      AlertDialog.Builder boite_confirmation = new AlertDialog.Builder(com.sodyam.philomabtontine.Vue.nouveau_paiement.this);
                      boite_confirmation.setTitle("CONFIRMATION DE PAIEMENT");
                      boite_confirmation.setMessage("Vous voulez enregistrer un paiement de " + montant_payer +
                              "F CFA  dans  la Carnet N° " + numcarnet + ", Voulez vous continuer ? ");

                      boite_confirmation.setPositiveButton("CONTINUER", new DialogInterface.OnClickListener() {
                          @Override
                          public void onClick(DialogInterface dialogInterface, int i) {
                              /**
                               * Insertion du paiement dans la Base de données:Table Paiement
                               */
                              Log.e(TAG,"Le nombre de paiement ------------------: "+ database.PaiementDao().getListePaiements().size());

                              if(CartnetExiste(num_carnet))
                              {
                                  SaveNewPaiement();
                                  Log.e(TAG,"Le nombre de paiement ------------------: "+ database.PaiementDao().getListePaiements().size());
                                  Log.e(TAG,"INFOS BIEN ENREGISTREES");

                                  Toast.makeText(com.sodyam.philomabtontine.Vue.nouveau_paiement.this, "Paiement Bien Enregistré !", Toast.LENGTH_SHORT).show();
                              }
                              else
                              {
                                  Toast.makeText(com.sodyam.philomabtontine.Vue.nouveau_paiement.this,"Ce Carnet n'existe pas !!", Toast.LENGTH_SHORT).show();
                              }
                          }
                      });

                      boite_confirmation.setNegativeButton("ANNULER", new DialogInterface.OnClickListener() {
                          @Override
                          public void onClick(DialogInterface dialogInterface, int i) {
                              Toast.makeText(com.sodyam.philomabtontine.Vue.nouveau_paiement.this, "Paiement Annulé ! ", Toast.LENGTH_SHORT).show();
                          }
                      });
                      boite_confirmation.show();
                  }
              }
          });
    }
    /**
     * CREER UN CLIENT_LOT
     */
   /* private  void  CreateNewClientLot()
    {
        T_Client_Lot nouveau_Client_Lot=new T_Client_Lot(mContentViewModel.getDernierClientEnregistre()+1,
                mContentViewModel.getLastClientLotCreated()+1);
        mContentViewModel.CreateNewClientlot(nouveau_Client_Lot);
    }*/


    /**
     * ENREGISTREMENT D'UN NOUVEAU PAIEMENT
     */

        public void  SaveNewPaiement()
        {
            init();
            T_Paiement newPaiement=new T_Paiement(num_carnet, poste.getSelectedItem().toString(),montant,date_paiement);
            database.PaiementDao().insertPaiement(newPaiement);
        }

    /**
     *Recuperation et valorisation des variables
     */

    @SuppressLint("WrongViewCast")
    private void init()
    {
        this.date_actuelle=(TextView) findViewById(R.id.date_actuelle);
        this.numcarnet=(EditText) findViewById(R.id.numCarnet);
        this.quote_part=(EditText) findViewById(R.id.quote_part);
        this.nom_client=(TextView)findViewById(R.id.nom_client);
        this.prenom_client=(TextView)findViewById(R.id.prenom_client);
        this.telephone=(TextView)findViewById(R.id.telephone_client);
        this.montant_payer= (TextView) findViewById(R.id.montant_paye);
        this.reste_payer=(TextView)findViewById(R.id.reste_paye);
       this.poste_agentE= (Spinner) findViewById(R.id.agent_enregistreur);

        if(Functions.checkIsEmpty(this,numcarnet) && Functions.checkIsEmpty(this,quote_part))
        {
            num_carnet=Integer.parseInt(numcarnet.getText().toString());
            montant=Integer.parseInt(quote_part.getText().toString());
        }

    }
    /**
     * Verification si les entrées sont correcte
     * @return
     */
    public boolean ValeursEntreesCorrects()
    {
        Boolean EntresCorrect=true;
        try {
            if(!CartnetExiste(this.num_carnet))
            {
                EntresCorrect=false;
                Toast.makeText(com.sodyam.philomabtontine.Vue.nouveau_paiement.this, "Ce Carnet n'existe pas ! ", Toast.LENGTH_SHORT).show();
            }
            if(montant%25!=0 || montant<25)
            {
                EntresCorrect=false;
                Toast.makeText(com.sodyam.philomabtontine.Vue.nouveau_paiement.this, "Montant Invalide ! ", Toast.LENGTH_SHORT).show();
            }

        }catch(Exception error){ }
        return  EntresCorrect;
    }

    /**
     * CONFIGURATON DU CONTENT VIEWMODEL
     */
    private void configureContentViewModel()
    {
        viewModelFactory mviewModelFactory= Injection.getViewModelFactory(this);
        this.mContentViewModel= ViewModelProviders.of(this, (ViewModelProvider.Factory) mviewModelFactory)
                .get(ContentViewModel.class);
    }


    /**
     * VERIFICATION DE L'EXISTENCE DU NUMERO DU CARNET
     */
    private Boolean CartnetExiste(Integer num_carnet) {
        Boolean carnetExiste = true;
        try {
            if(!database.CarnetDao().getNumerosDesCarnets().contains(num_carnet))
            {
                carnetExiste=false;
            }

        } catch (Exception err) {
        }
        return carnetExiste;
    }
    /**
     * Methode Verifiant si tout les Champs sont renseignés
     * @return
     */

    public boolean InfosPaiementEstVide()
    {

        return (Functions.checkIsEmpty(this,numcarnet) && Functions.checkIsEmpty(this,quote_part));

        }

}