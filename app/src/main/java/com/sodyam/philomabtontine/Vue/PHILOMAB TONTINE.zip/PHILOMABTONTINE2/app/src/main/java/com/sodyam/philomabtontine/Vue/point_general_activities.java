package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.sodyam.philomabtontine.ContentViewModel;
import com.sodyam.philomabtontine.Injection.Injection;
import com.sodyam.philomabtontine.Injection.viewModelFactory;
import com.sodyam.philomabtontine.R;


public class point_general_activities extends AppCompatActivity {
    private EditText date_debut,date_fin;
    private TextView nombre_gobal_client,nombre_global_carnet_vendu,chiffre_global_carte,quote_part_global,
    benefices_global,montant_gobal_attendu,chiffre_global_acticities;
    private Button btn_executer_recherche_point_global,btn_quitter_recherche;
    private ContentViewModel mContentViewModel;

   // private Point_general general_point;

    //Transformation des variables datas en Type chh=
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_general_activities);
        init_point_global();
        String date_start=date_debut.getText().toString();
        String date_end=date_fin.getText().toString();

        /**
         * ACTION APRES CLIC SUR LE BOUTON ACTUALISER RECHERCHE
         */

        btn_executer_recherche_point_global.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // A  traiter
            }
        });
        /*if(btn_executer_recherche_point_global!=null)
        //nombre_gobal_client.setText(mContentViewModel.getPoint_General_Activities().getNombre_client_total());
        nombre_global_carnet_vendu.setText(mContentViewModel.getPoint_General_Activities().getCarnet_total_vendu());
        chiffre_global_carte.setText(mContentViewModel.getPoint_General_Activities().getMontant_carnet());
        quote_part_global.setText(mContentViewModel.getPoint_General_Activities().getMontant_total_collecte());
        benefices_global.setText(mContentViewModel.getPoint_General_Activities().getBenefice_total());
        montant_gobal_attendu.setText(mContentViewModel.getPoint_General_Activities().getMontant_rendu());
        chiffre_global_acticities.setText(mContentViewModel.getPoint_General_Activities().getChiffre_affaire_total());*/

        /**
         * ACTION APRES AVOIR CLIQUER SUR LE BOUTON QUITTER POINT GENERALE
         */
        btn_quitter_recherche.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersMenu=new Intent(getApplicationContext(),Menu.class);
                startActivity(VersMenu);
                finish();
            }
        });

    }

    //Recuperation et Valorisation des variables
    private  void init_point_global()
    {
        this.btn_executer_recherche_point_global=(Button) findViewById(R.id.btn_actualiser_recherche);
        this.btn_quitter_recherche=(Button) findViewById(R.id.btn_quitter_point_general);
        this.date_debut=(EditText) findViewById(R.id.saisi_date_debut);
        this.date_fin=(EditText) findViewById(R.id.saisi_date_fin);
        this.nombre_gobal_client=(TextView) findViewById(R.id.nombre_total_client);
        this.nombre_global_carnet_vendu=(TextView) findViewById(R.id.nombre_carnet_vendu);
        this.chiffre_global_carte= (TextView)findViewById(R.id.montant_carnet);
        this.quote_part_global=(TextView)findViewById(R.id.total_quote_part_general);
        this.benefices_global=(TextView)findViewById(R.id.benefices);
        this.montant_gobal_attendu=(TextView)findViewById(R.id.montant_attendu);
        this.chiffre_global_acticities=(TextView)findViewById(R.id.chiffre_affaire_global);
    }

    private void configureContentViewModel()
    {
        viewModelFactory mviewModelFactory= Injection.getViewModelFactory(this);
        this.mContentViewModel= ViewModelProviders.of(this, (ViewModelProvider.Factory) mviewModelFactory)
                .get(ContentViewModel.class);
    }
}