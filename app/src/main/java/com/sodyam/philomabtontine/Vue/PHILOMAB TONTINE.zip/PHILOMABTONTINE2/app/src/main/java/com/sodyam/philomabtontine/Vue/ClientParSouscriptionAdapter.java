package com.sodyam.philomabtontine.Vue;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.Outils.client_par_souscription;
import com.sodyam.philomabtontine.R;

import java.util.List;

public class ClientParSouscriptionAdapter extends RecyclerView.Adapter<ClientParSouscriptionAdapter.ExampleViewHolder> {

    private Context mContext;
    private List<client_par_souscription> mExampleList;
    private ClientParSouscriptionAdapter.OnItemClickListenner mListenner;
    private  Databasephilomabtontine database;


    //database=Databasephilomabtontine.getInstance(getApplicationContext());

    public interface OnItemClickListenner {
        void onItemClick(int position);
    }

    public void setOnClickListenner(ClientParSouscriptionAdapter.OnItemClickListenner listenner) {
        mListenner = listenner;
    }

    public ClientParSouscriptionAdapter(Context context, List<client_par_souscription> example_categoryList) {
        mContext = context;
        mExampleList = example_categoryList;
        notifyDataSetChanged();
    }

    @Override
    public ClientParSouscriptionAdapter.ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.client_par_sousription_single_item, parent, false);
        return new ClientParSouscriptionAdapter.ExampleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ClientParSouscriptionAdapter.ExampleViewHolder holder, int position) {
        final Databasephilomabtontine database=Databasephilomabtontine.getInstance(mContext.getApplicationContext());
        client_par_souscription currentItem = mExampleList.get(position);
      Log.e(TAG,"CLIENT PAR SOUSCRIPTION : ................................."+database.PaiementDao().getClientBySouscription().size());
        holder.nom_client.setText(currentItem.getNom_cli());
        holder.prenom_client.setText(currentItem.getPrenom_cli());
        Log.e(TAG,"CLIENT PAR SOUSCRIPTION : ................................."+currentItem.getNumCarnet());
        //holder.telephone_client.setText(database.ClientDao().getClientByNumCarnet(currentItem.getNumCarnet()).getTelephone());
        holder.valeur_souscription.setText((currentItem.getValeur_souscript())+" F CFA");
        holder.montant_paye.setText(currentItem.getMontant_paye()+" F CFA ");
        holder.reste_paye.setText(currentItem.getReste_paye()+" F CFA");
        //holder.mont_dernier_paye.setText(currentItem.getMontant_dernier_paiement().intValue()+" F CFA ");
        //holder.date_dernier_paye.setText(currentItem.getDate_dernier_paiement());
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }


    public class ExampleViewHolder extends RecyclerView.ViewHolder{

        private TextView mont_dernier_paye;
        private TextView date_dernier_paye;
        private TextView valeur_souscription;
        private TextView nom_client;
        private TextView prenom_client;
        private TextView telephone_client;
        private TextView montant_paye;
        private TextView reste_paye;


        public ExampleViewHolder(View itemView) {
            super(itemView);
            mont_dernier_paye=itemView.findViewById(R.id.mont_dernier_paye);
            date_dernier_paye=itemView.findViewById(R.id.date_dernier_paye);
            valeur_souscription=itemView.findViewById(R.id.valeur_souscription);
            nom_client=itemView.findViewById(R.id.nom_client);
            prenom_client=itemView.findViewById(R.id.prenom_client);
            telephone_client=itemView.findViewById(R.id.telephone_client);
            montant_paye=itemView.findViewById(R.id.montant_paye);
            reste_paye=itemView.findViewById(R.id.reste_paye);
        }
    }
}
