package com.sodyam.philomabtontine;

import android.content.Context;

import com.sodyam.philomabtontine.Injection.Injection;
import com.sodyam.philomabtontine.Injection.viewModelFactory;

public class ContentViewModelConfigure {
    private ContentViewModel mContentViewModel;

    //Configuration du Model View

   /* private  ContentViewModel configurationContentViewModel(Context context)
    {

        viewModelFactory viewModelFactory=Injection.getViewModelFactory(context);
        this.v
    }*/

}
