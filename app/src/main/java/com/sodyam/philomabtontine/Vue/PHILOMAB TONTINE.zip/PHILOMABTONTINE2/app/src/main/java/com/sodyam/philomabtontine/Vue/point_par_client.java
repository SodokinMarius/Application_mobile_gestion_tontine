package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.R;

public class point_par_client extends AppCompatActivity {

    private Button quiter_point_par_client;
    private SearchView zone_recherche_client;
    private TextView nombre_total_clients,montant_dernier_paiement,date_dernier_paiement,nom_cli,prenom_cli,
            lot_choisi,montant_paye,reste_paye,valeur_souscript,date_actuelle;
    private Databasephilomabtontine database;
    private RecyclerView recyclerView;
    private  ClientParSouscriptionAdapter adapter;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_par_client);
        init();
        quiter_point_par_client.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent versMenu=new Intent(getApplicationContext(),Menu.class);
                startActivity(versMenu);
                finish();
            }
        });
    }

    private void init()
    {
        this.montant_dernier_paiement= (TextView) findViewById(R.id.mont_dernier_paye);
        this.date_dernier_paiement=(TextView) findViewById(R.id.date_dernier_paye);
        this.nom_cli=(TextView) findViewById(R.id.nom_client);
        this.prenom_cli=(TextView) findViewById(R.id.prenom_client);

        this.zone_recherche_client=(SearchView) findViewById(R.id.zone_recherche_client);
        this.nombre_total_clients=(TextView) findViewById(R.id.nombre_total_client);

        this.quiter_point_par_client=(Button) findViewById(R.id.btn_quiter_point_par_client);
    }
}