package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.sodyam.philomabtontine.R;

public class point_par_type_lot extends AppCompatActivity {

    private Button quiter_point_par_type_lot;
    private SearchView zone_recherche_lot;
    private TextView nombre_total_clients,montant_dernier_paiement,date_dernier_paiement,nom_cli,prenom_cli,
            lot_choisi,montant_paye,reste_paye,valeur_souscript,date_actuelle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_par_type_lot);
        init();
        quiter_point_par_type_lot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent versMenu=new Intent(getApplicationContext(), com.sodyam.philomabtontine.Vue.Menu.class);
                startActivity(versMenu);
                finish();
            }
        });
    }

    private void init()
    {

        this.zone_recherche_lot=findViewById(R.id.zone_recherche_lot);
        this.nombre_total_clients=findViewById(R.id.nombre_total_type_lot);

        this.quiter_point_par_type_lot=findViewById(R.id.btn_quitter_client_par_type_lot);
    }
}