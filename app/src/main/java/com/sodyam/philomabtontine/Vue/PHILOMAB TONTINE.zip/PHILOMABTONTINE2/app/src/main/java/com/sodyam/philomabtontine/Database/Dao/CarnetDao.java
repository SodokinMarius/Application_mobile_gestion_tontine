package com.sodyam.philomabtontine.Database.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.sodyam.philomabtontine.model.T_Carnet;

import java.util.List;


@Dao
public interface CarnetDao {
    @Query("SELECT * FROM T_Carnet ")
    List<T_Carnet> getListeCarnets();

    /**
     * RECUPERATION DES NUMEROS DES CARNETS
     */
    @Query("SELECT NumeroCarnet FROM T_Carnet ")
   List<Integer> getNumerosDesCarnets();

    /**
 * RECUPERATION DU NUMERO DU DERNIER CARNET
 */
    @Query("SELECT MAX(NumeroCarnet) FROM T_Carnet ")
    int getIdDernierCarnet();

    /**
     * Le nombre total de carnet Vendu genenralement
     * @return
     */
    @Query("SELECT COUNT(*) FROM T_Carnet ")
    Integer getNombre_General_Carnet_Vendu();

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void  createCarnet(T_Carnet carnet);

    @Update
    int updateCarnet(T_Carnet carnet);

    @Query("DELETE FROM T_Carnet where NumeroCarnet=:numCarnet")
    void  deleteCarnet(long numCarnet);
}
