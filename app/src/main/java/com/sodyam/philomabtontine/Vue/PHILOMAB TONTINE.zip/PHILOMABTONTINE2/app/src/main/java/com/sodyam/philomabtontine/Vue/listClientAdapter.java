package com.sodyam.philomabtontine.Vue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sodyam.philomabtontine.Outils.List_client;
import com.sodyam.philomabtontine.R;

import java.util.List;

public class listClientAdapter extends RecyclerView.Adapter<listClientAdapter.ExampleViewHolder> {
    private Context mContext;
    private List<List_client> mExampleList;
    private OnItemClickListenner mListenner;



    public interface OnItemClickListenner {
        void onItemClick(int position);
    }

    public void setOnClickListenner(OnItemClickListenner listenner) {
        mListenner = listenner;
    }
    public listClientAdapter(Context context, List<List_client> example_categoryList) {
        mContext = context;
        mExampleList = example_categoryList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public listClientAdapter.ExampleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.content_adapter, parent, false);
        return new ExampleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ExampleViewHolder holder, int position) {
        List_client currentItem = mExampleList.get(position);

        holder.numCarnet.setText(Integer.toString(currentItem.getNumeroCarnet()));
        holder.nom_client.setText(currentItem.getNom());
        holder.prenom_client.setText(currentItem.getPrenom());
        holder.contactclient.setText(Long.toString(currentItem.getTelephone()));
        holder.lot_souscrit.setText(Long.toString(currentItem.getIdLot()));
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }

    public class ExampleViewHolder extends RecyclerView.ViewHolder{

        private TextView nom_client;
        private TextView prenom_client;
        private TextView numCarnet;
        private TextView contactclient;
        private TextView lot_souscrit;


        public ExampleViewHolder(View itemView) {
            super(itemView);
            contactclient = itemView.findViewById(R.id.contactclient);
            nom_client= itemView.findViewById(R.id.nom_client);
            prenom_client=itemView.findViewById(R.id.prenom_client);
            numCarnet=itemView.findViewById(R.id.numCarnet);
            lot_souscrit=itemView.findViewById(R.id.lot_souscrit);
        }
    }
}
