package com.sodyam.philomabtontine.Database.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.sodyam.philomabtontine.model.T_Lot;

import java.util.List;

@Dao
public interface LotDao {
    @Query("SELECT * FROM T_Lot")
    List<T_Lot> getListesLots();

    //Nombre total de souscription
    @Query("SELECT COUNT(T_Lot.montant_lot) FROM T_Lot")
   Integer getNombreTotalDeLot();

    @Query("SELECT montant_lot FROM T_Lot ")
    List<Long> getListesMontantExistants();

     //RECUPERATION DE LA DATE D'AJOUT D'UN LOT CONNAISSANT SA VALEUR
    @Query("SELECT date_ajout FROM T_Lot where montant_lot=:montant")
    Integer getDateAjoutKnownLot(Integer montant);

    //Nombre total de Type Lot
    @Query("SELECT COUNT(type_lot) FROM T_Lot GROUP BY type_lot")
    Integer getNombreTotalTypeLot();
    @Insert(onConflict = OnConflictStrategy.IGNORE)
  void insertLot(T_Lot Lot);

    @Update
    int updateLot(T_Lot Lot);

    @Query("DELETE FROM T_Paiement where IdPaiement= :numLot")
    int deleteLot(long numLot);

}
