package com.sodyam.philomabtontine.Vue;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sodyam.philomabtontine.Databasephilomabtontine;
import com.sodyam.philomabtontine.Outils.Point_par_souscription;
import com.sodyam.philomabtontine.R;


public class point_par_souscription extends AppCompatActivity {
    private Button boutton_quiter_point_par_souscrition;
    private TextView date_actuelle;
    private TextView nmbre_total_souscription,type_souscription,nmbre_de_client;
    private Databasephilomabtontine database;
    private PointParSouscriptionAdapter adapter;
    private RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_par_souscription);
        //init_point_par_souscrit();
        this.boutton_quiter_point_par_souscrition=findViewById(R.id.btn_quiter_point_souscription);
        this.date_actuelle=findViewById(R.id.date_actuelle);
        this.nmbre_total_souscription=findViewById(R.id.nombre_total_souscription);
        this.type_souscription=findViewById(R.id.souscription_valeur);
        this.nmbre_de_client=findViewById(R.id.nbre_client);


        /**
         * AFFICHAGE DES INFORMATIONS DE LA BASE DE DONNEES
         */
        for(Point_par_souscription point : database.PaiementDao().getPointBySouscription())
        {
            recyclerView = findViewById(R.id.Unclient);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new PointParSouscriptionAdapter(getApplicationContext(), database.PaiementDao().getPointBySouscription());
            recyclerView.setAdapter(adapter);
        }

        boutton_quiter_point_par_souscrition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent VersMenuPrincipal=new Intent(getApplicationContext(),Menu.class);
                startActivity(VersMenuPrincipal);
                finish();
            }
        });
    }

    //Valorisation des atributs
    private void init_point_par_souscrit()
    {

    }
}