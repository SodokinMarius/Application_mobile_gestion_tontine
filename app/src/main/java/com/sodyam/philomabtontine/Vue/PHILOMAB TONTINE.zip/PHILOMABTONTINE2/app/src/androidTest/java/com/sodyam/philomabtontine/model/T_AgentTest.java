package com.sodyam.philomabtontine.model;

import junit.framework.TestCase;

public class T_AgentTest extends TestCase {

}