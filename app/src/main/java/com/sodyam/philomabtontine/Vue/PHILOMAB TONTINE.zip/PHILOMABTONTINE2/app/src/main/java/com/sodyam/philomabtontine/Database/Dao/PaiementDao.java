package com.sodyam.philomabtontine.Database.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.sodyam.philomabtontine.Outils.Liste_paiements;
import com.sodyam.philomabtontine.Outils.Point_general_activities;
import com.sodyam.philomabtontine.Outils.Point_jour;
import com.sodyam.philomabtontine.Outils.Point_par_souscription;
import com.sodyam.philomabtontine.Outils.client_par_souscription;
import com.sodyam.philomabtontine.Outils.dernierPaiementInfos;
import com.sodyam.philomabtontine.Outils.infosPaiements;
import com.sodyam.philomabtontine.Outils.pointParTypeLot;
import com.sodyam.philomabtontine.model.T_Paiement;

import java.util.Date;
import java.util.List;

@Dao
public interface PaiementDao {
    long montant_carnet=0;
    long chiffre_Affaire_jour=0;
    Date date_ajout = new Date();

    @Query("SELECT * FROM T_Paiement")
   List<T_Paiement> getListePaiementsUnique();

    //String date_convert= date_ajout.toString();
    /**
     * Les methoses consernant le point general de l'activité
     */
    //montant total des quotes parts en general
    @Query("SELECT sum(montant_paye)  FROM T_Paiement")
    Long getMontant_Total_General();


        //Nombre de Carnet Vendu le dernier jour
        @Query("SELECT  count(NumeroCarnet) FROM T_Carnet ")
        Long getNombreCarnet_Vendu_By_Jour();


    //Calcul du montant payé le dernier jour
    @Query("SELECT sum(montant_paye) from T_Paiement ")
    Long get_Montant_collecte_Jour();


    /**
     * Methode qui rtourne le point general du Jour
     * @return
     */
    @Query("SELECT  count(T_Carnet.NumeroCarnet) as Nombre_Carnet_Vendu," +
            " (count(T_Carnet.NumeroCarnet)*300) as montant_carnet, " +
            " SUM(T_Paiement.montant_paye) as montant_du_jour, " +
            " ((count(T_Carnet.NumeroCarnet)*300)+SUM(T_Paiement.montant_paye))as chiffre_Affaire_jour " +
            "FROM T_Carnet inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet " +
            "where T_Carnet.date_ajout=:date_convert" +
            " AND  T_Paiement.date_paiement=:date_convert")
    Point_jour getPointDuJour(Integer date_convert);

    //Methode qui renvoie la date d'enregistrement du tout premier Carnet
    //Cette date servira à initialier par defaut la date de debut
    //du point general au cas où l'agent ne le precisera pas
    @Query("SELECT date_ajout FROM T_Carnet where NumeroCarnet=1")
   Integer getDatePremierEnregistrement();


    /**
     * //Methode qui retourne le point general de l'activité
     * @return
     */
    @Query("SELECT  COUNT(T_Client.Matricule) as nombre_client_total, " +
            " count(T_Carnet.NumeroCarnet) as carnet_total_vendu," +
            " (count(T_Carnet.NumeroCarnet)*300) as montant_carnet, " +
            " sum(T_Paiement.montant_paye) as montant_total_collecte, " +
            " sum(T_Lot.montant_lot*12) as benefice_total, " +
            " (sum(T_Paiement.montant_paye) -sum(T_Lot.montant_lot*12)) as montant_rendu, " +
            " (sum(T_Paiement.montant_paye)+(count(T_Carnet.NumeroCarnet)*300))as chiffre_affaire_total " +
            " FROM T_Carnet inner join T_Client on T_Client.Matricule=T_Carnet.idClient " +
            " inner join T_Lot on T_Carnet.IdLot=T_Lot.montant_lot" +
            " inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet")
            /*" where T_Carnet.date_ajout between :date_debut and :date_fin" +
            " AND T_Paiement.date_paiement between :date_debut and :date_fin")*/
            Point_general_activities getPointGeneral(/*String date_debut,String date_fin*/);



    //Methode retournant la liste des points DATE DERNIER ET DERNIER PAIEMENT client mais connaissant son Marticule
        @Query("SELECT T_Paiement.montant_paye as montant_dernier_paiement, " +
                "T_Paiement.date_paiement as date_dernier_paiement " +
                "FROM T_Carnet inner join T_Client on T_Client.Matricule=T_Carnet.idClient " +
                "inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet " +
                "WHERE IdPaiement=(SELECT max(IdPaiement) FROM T_Paiement) " +
                "AND T_Client.Matricule=:numclient ")
        dernierPaiementInfos getDernierPaiementGeneralById(Integer numclient);


        @Query("SELECT  T_Client.Nom,T_Client.Prenom," +
                "T_Client.Nom,T_Client.Prenom," +
                "T_Carnet.NumeroCarnet as numero_carnet," +
                "T_Carnet.IdLot as lot_choisi, " +
                "SUM(T_Paiement.montant_paye) as montant_paye," +
                " ((T_Carnet.IdLot*372)-montant_paye) as reste_paye " +
                "FROM T_Client inner join T_Carnet on " +
                "T_Client.Matricule=T_Carnet.IdClient " +
                "inner join T_Lot on T_Carnet.IdLot=T_Lot.montant_lot " +
                "inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet " +
                "WHERE T_Carnet.NumeroCarnet=:numcarnet")
        infosPaiements getInfosPaiementClientById(Integer numcarnet);


    @Query("SELECT  T_Client.Nom,T_Client.Prenom, " +
            "T_Carnet.NumeroCarnet as numero_carnet, " +
            "T_Carnet.IdLot as lot_souscript, " +
            "SUM(T_Paiement.montant_paye) as montant_paye," +
            " ((T_Carnet.IdLot*372)-SUM(T_Paiement.montant_paye)) as reste_paye " +
            "FROM T_Client inner join T_Carnet on " +
            "T_Client.Matricule=T_Carnet.IdClient " +
            "inner join T_Lot on T_Carnet.IdLot=T_Lot.montant_lot " +
            "inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet "/* +
            "GROUP BY lot_souscript ORDER BY lot_souscript "*/)
    List<client_par_souscription> getClientBySouscription();

    /**
     * POINT PAR SOUSCRIPTION
     */
    @Query("SELECT montant_paye, COUNT(montant_paye) FROM T_Paiement " +
            "GROUP BY montant_paye ORDER BY montant_paye")
    List<Point_par_souscription> getPointBySouscription();

    /**
     * RECUPERER LE NOMBRE DE CLIENT ENREGISTRE CONNAISSANT LE POSTE DE L'AGENT
     */
        @Query("SELECT COUNT(numCarnet) as nombreCarnet FROM T_Paiement  WHERE poste_agent=:poste ")
        Integer getNombreClientEnregistreByPoste(String poste);

    /**
     * Methode renvoyant le point par type de lot
     * @param idClient
     * @return
     */
    @Query("SELECT  T_Client.Nom,T_Client.Prenom, " +
            " T_Client.Telephone as telephone," +
            " T_Lot.type_lot as type_lot," +
            " sum(T_Paiement.montant_paye) as montant_paye," +
            " ((T_Carnet.IdLot*372)-montant_paye) as reste_paye " +
            "FROM T_Client inner join T_Carnet on " +
            " T_Client.Matricule=T_Carnet.IdClient" +
            " inner join T_Lot on T_Carnet.IdLot=T_Lot.montant_lot" +
            " inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet" +
            " WHERE T_Client.Matricule=:idClient")
   pointParTypeLot getInfosPaiementClientTypelotById(Integer idClient);

    /**
     * Methode qui se charge recuperer la liste des Paiements
     * @return
     */
    //Methode renvoyant la liste des Paiements
    @Query("SELECT  T_Client.Nom,T_Client.Prenom," +
            "T_Carnet.NumeroCarnet as numero_carnet, " +
            "T_Paiement.montant_paye as montant_dernier_paiement,"+
            "T_Paiement.date_paiement as date_paiement," +
            "T_Agent.Poste as poste_agent, " +
            "SUM(T_Paiement.montant_paye) as montant_paye," +
            " ((T_Carnet.IdLot*372)-montant_paye) as reste_paye " +
            "FROM T_Client inner join T_Carnet on " +
            "T_Client.Matricule=T_Carnet.IdClient " +
            "inner join T_Lot on T_Carnet.IdLot =T_Lot.montant_lot " +
            "inner join T_Paiement on T_Carnet.NumeroCarnet=T_Paiement.numCarnet " +
            "inner join T_Agent on T_Agent.Poste=T_Paiement.poste_agent " +
            "ORDER BY T_Paiement.date_paiement  ASC")
    List<Liste_paiements> getListePaiements();


    /**
     * MONTANT et date du DERNIER PAIEMENT
     * @param
     * @return
     */
    @Query("SELECT montant_paye FROM T_Paiement " +
            "inner join T_Carnet on T_Paiement.numCarnet=T_Carnet.NumeroCarnet " +
            "inner join T_Client on T_Carnet.IdClient=T_Client.Matricule " +
            "WHERE IdPaiement= (SELECT MAX(IdPaiement) FROM T_Paiement )" +
            "AND T_Carnet.NumeroCarnet=:numcarnet")
    Long getDernierPaiementDuClient(Integer numcarnet);


    @Query("SELECT montant_paye FROM T_Paiement " +
            "inner join T_Carnet on T_Paiement.numCarnet=T_Carnet.NumeroCarnet " +
            "inner join T_Client on T_Carnet.IdClient=T_Client.Matricule " +
            "WHERE IdPaiement= (SELECT MAX(IdPaiement) FROM T_Paiement )" +
            "AND  T_Carnet.NumeroCarnet=:numcarnet")
    Long getDateDernierPaiementDuClient(Integer numcarnet);

    //Montant total payer par un client connaissant son numero de Carnet
    @Query("SELECT SUM(T_Paiement.montant_paye) FROM T_Paiement WHERE numCarnet=:numCarnet")
   Long getMontantPayeByNumCarnet(Integer numCarnet);

        //Creation d'un paiement
        @Insert
        void insertPaiement (T_Paiement paiement);

        @Update
        int updatePaiement (T_Paiement paiement);

        @Query("DELETE FROM T_Paiement where IdPaiement= :numPaiement")
        int deletePaiement ( long numPaiement);

}
